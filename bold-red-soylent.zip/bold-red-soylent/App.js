import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Juat Jairus");
  const bodyText = 'Im Jairus Ilagan Juat. I expirience in my Sysarch 1 is on how to manage my time and to prepare all the things in my paper works. me as a provider speaker i will discuss all the details and provide extra imformation and examples. It is not easy and i dont know what im going to do in my Sysarch or reaserchh, me and my group im the head of the group, Im the leader. Me as a leader ill do respect and give some motivational spirit and knowledge to all my members, succeedd is not easy but you can do all the thigs to b come part of your4 group and on how to determained your pressentation. this project is all about inventory and we do all honnor all my members specially the Pannles, Sir Ariel is the one greate and motivation proffessor, one of a kind and a lot of responsibility and give a lot of chance to finish the projet or sysarcvh reaserch. To be honnor for my leader sir ariel is one of the strict professor but things a lot of changes and make opportunity to do all part by part, no matter what it is is we need to finish the target tittle in this reasearch, one upon a day in more a lot o potential activity and make gained lnowledge to do. it is not valid but suddenly make more proud and creative to be come a part anot a leader not a member but be the part of it, Individual.';
  const onPressTitle = () => {
    setTitleText("Bird's Nest [pressed]");
  };

 return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <Text style={styles.baseText}>
          <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
          </Text>
          <Text numberOfLines={5}>{bodyText}</Text>
        </Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  baseText: {
    fontFamily: 'Cochin',
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default TextInANest;